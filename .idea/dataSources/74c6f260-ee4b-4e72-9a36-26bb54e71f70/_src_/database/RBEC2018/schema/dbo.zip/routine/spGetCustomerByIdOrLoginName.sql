-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
---1-4-1 查询客户信息
--DROP  PROCEDURE spGetCustomerByIdOrLoginName

CREATE  PROCEDURE spGetCustomerByIdOrLoginName
    @IDOrLoginName VARCHAR(20)
AS
BEGIN
	SET NOCOUNT ON;
	SELECT CustomerID
				, CustomerName
				, CustomerLoginName
				, CustomerPassword
				, CustomerPhone
				, CustomerPwdQuestion
				, CustomerPwdAnswer
				, CustomerRemark
		    FROM RBEC2018.dbo.tblCustomer
		    WHERE CustomerID = @IDOrLoginName 
			OR CustomerLoginName = @IDOrLoginName;
	    
END
GO
