-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
---1-2-1、删除客户信息
--DROP  PROCEDURE spDeleteCustomerByIDOrLoginName

CREATE  PROCEDURE spDeleteCustomerByIDOrLoginName
    @Result nvarchar(500)  out
   ,@IDOrLoginName VARCHAR(20)   
AS
BEGIN
	SET NOCOUNT ON;
	BEGIN TRY
		DELETE FROM tblCustomer 
			WHERE CustomerID= @IDOrLoginName 
			OR CustomerLoginName= @IDOrLoginName;
		SET @Result=N'OK';	
	END TRY
	BEGIN CATCH
	    SET @Result = ERROR_MESSAGE();		    
	END CATCH		   
END
GO
