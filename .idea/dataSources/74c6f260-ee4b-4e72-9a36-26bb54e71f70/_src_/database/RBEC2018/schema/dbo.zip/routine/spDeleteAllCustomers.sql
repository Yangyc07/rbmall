-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================

CREATE  PROCEDURE spDeleteAllCustomers
    @Result nvarchar(500)  out
AS
BEGIN
	SET NOCOUNT ON;
	BEGIN TRY
		DELETE FROM tblCustomer;
		SET @Result=N'OK';	
	END TRY
	BEGIN CATCH
	    SET @Result = ERROR_MESSAGE();		    
	END CATCH		   
END
GO
