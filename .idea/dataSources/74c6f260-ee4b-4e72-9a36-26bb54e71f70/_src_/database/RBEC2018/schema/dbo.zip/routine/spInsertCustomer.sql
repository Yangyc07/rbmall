-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE  PROCEDURE spInsertCustomer
    @Result nvarchar(500)  out
   ,@CustomerID VARCHAR(20)
   ,@CustomerName NVARCHAR(50)
   ,@CustomerLoginName VARCHAR(20)
   ,@CustomerPassword VARCHAR(50)
   ,@CustomerPhone VARCHAR(10) =  NULL
   ,@CustomerPwdQuestion NVARCHAR(50) = NULL
   ,@CustomerPwdAnswer NVARCHAR(50) = NULL
   ,@CustomerRemark NVARCHAR(100) = NULL
AS
BEGIN
	SET NOCOUNT ON;
	BEGIN TRY
		INSERT INTO tblCustomer(CustomerID
								,CustomerName
								,CustomerLoginName
								,CustomerPassword
								,CustomerPhone
								,CustomerPwdQuestion
								,CustomerPwdAnswer
								,CustomerRemark)
			 VALUES(@CustomerID
					,@CustomerName
					,@CustomerLoginName
					,@CustomerPassword
					,@CustomerPhone
					,@CustomerPwdQuestion
					,@CustomerPwdAnswer
					,@CustomerRemark
					); 
		SET @Result=N'OK';	
	END TRY
	BEGIN CATCH
	    SET @Result = ERROR_MESSAGE();		    
	END CATCH		   
END
GO
