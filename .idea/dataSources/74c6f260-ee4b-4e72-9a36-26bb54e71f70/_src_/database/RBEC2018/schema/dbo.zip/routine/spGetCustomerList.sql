-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
---1-4-2 查询客户清单
--DROP  PROCEDURE spGetCustomerList

CREATE  PROCEDURE spGetCustomerList     
AS
BEGIN
	SET NOCOUNT ON;
	SELECT CustomerID
				, CustomerName
				, CustomerLoginName
				, CustomerPassword
				, CustomerPhone
				, CustomerPwdQuestion
				, CustomerPwdAnswer
				, CustomerRemark
		    FROM RBEC2018.dbo.tblCustomer;	    
END
GO
