-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
---1-3-1、修改客户信息
--DROP  PROCEDURE spUpdateCustomerPWDByIDOrLoginName

CREATE  PROCEDURE spUpdateCustomerPWDByIDOrLoginName
    @Result nvarchar(500)  out
    ,@IDOrLoginName VARCHAR(20) 
    ,@CustomerPassword VARCHAR(50)
AS
BEGIN
	SET NOCOUNT ON;
	BEGIN TRY
		UPDATE tblCustomer SET CustomerPassword = @CustomerPassword
			WHERE CustomerID = @IDOrLoginName 
			OR CustomerLoginName = @IDOrLoginName;
		SET @Result=N'OK';	
	END TRY
	BEGIN CATCH
	    SET @Result = ERROR_MESSAGE();		    
	END CATCH		   
END
GO
